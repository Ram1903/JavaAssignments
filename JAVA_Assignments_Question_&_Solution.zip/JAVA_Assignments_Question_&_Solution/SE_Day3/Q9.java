package SE_Day3;
//
// 9) create int array of 5 elements and accept 5 values inside it. Now accept one more number and check whether that number is there inside array or not.
import java.util.Scanner;
public class Q9 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int arr[]=new int[5];
        System.out.println("Enter 5 elements");
        for(int i=0;i<5;i++){
            arr[i]=sc.nextInt();
        }
        System.out.println("Old array");
        for(int i=0;i<5;i++){
            arr[i]=arr[i];
        }
        int aarr[]=new int[6];
        for(int i=0;i<5;i++){
            aarr[i]=arr[i];
        }
        System.out.println("Enter 6th element");
        aarr[5]=sc.nextInt();
        for(int i=0;i<6;i++){
            System.out.print(aarr[i]);
        }
    }
    
}
