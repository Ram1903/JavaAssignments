package SE_Day3;
//
import java.util.Scanner;
//7) accept a number and display whether it is even , odd or zero.
public class Q7 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int n=sc.nextInt();
        if(n%2==0){
            System.out.println("Its an even number");
        }else{
            System.out.println("Not even");
        }
    }
    
}
