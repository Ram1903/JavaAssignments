package SE_Day3;
/*
 

14) display prime numbers from 2 to 20

15) accept a number and display whether it is prime or not.
 */
import java.util.Scanner;
public class Q14_15 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println(" ");
        
        for(int i=2;i<=20;i++){
            int c=0;
            for(int j=2;j<i;j++){
                if(i%j==0){
                    c++;
                }
            }
            if(c==0){
                System.out.print(i+" ");
            }
        }

        System.out.println();
        System.out.println("Enter a number");
        int n=sc.nextInt();

        
       int p=0;
            for(int j=2;j<n;j++){
                if(n%j==0){
                    p++;
                }
            }
            if(p==0){
                System.out.print("prime number");
            
        }else{
            System.out.println("Not a prime");
        }
    }
    
}
