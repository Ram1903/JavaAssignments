package SE_Day3;
import java.util.Scanner;

//
//6) accept numbers and display as long as user does not enter 0.
public class Q6 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int n=sc.nextInt();
        do{
            System.out.println(n);
            System.out.println("Enter a number");
            n=sc.nextInt();
        }while(n!=0);
    }
    
}
