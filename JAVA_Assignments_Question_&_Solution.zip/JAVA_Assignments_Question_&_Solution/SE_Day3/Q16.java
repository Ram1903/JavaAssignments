package SE_Day3;

/*
 
16) accept 3 digit number and display whether it is armstrong or not.
	[ A number is called as armstrong number if sum of cubes of digits of number is equal to the number itself ]
 */
import java.util.Scanner;
public class Q16 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int cn=n;
        int sum=0;
        while(n>0){
            int rem=n%10;
            n=n/10;
            sum=sum*10+rem;
        }

        if(sum==cn){
            System.out.println("Armstrong number");
        }else{
            System.out.println("Not an armstrong number");
        }
    }
    
}
