package SE_Day3;
//

//2) accept a number and display whether it is divisible by 7 or not.
import java.util.Scanner;
public class Q2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int n=sc.nextInt();
        if(n%7==0)
           System.out.println("Divisible by 7");
           else
           System.out.println("Not divisible by 7");
    }
}
