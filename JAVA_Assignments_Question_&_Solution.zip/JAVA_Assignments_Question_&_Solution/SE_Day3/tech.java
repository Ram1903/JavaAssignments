package SE_Day3;
import java.util.Scanner;

import Day6.stu;
class Person {
    // Instance variables
    String name;
    int age;
    
    // Constructor to initialize instance variables
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    // Instance method
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

class student{
    //non-static block execute before any constructor executes
    
    public static void me(){
        System.out.println("Static");
    }
    public void s2()
    {
        System.out.println("non Ststic class");
    }
}
public class tech {
    public static void main(String[] args) {
        System.out.println(" ");
        student s=new student();
       //
       // s.student();
    }
}
