package SE_Day3;
/*
 
12) accept 2 numbers and display whether
	a) first number is greater
	b) second number is greater
	c) both are equal


 */
import java.util.Scanner;
public class Q12 {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two numbers");
        int a=sc.nextInt();
        int b=sc.nextInt();
        if(a==b)
          System.out.println("both are equal");
          else if(a>b){
            System.out.println("first is greate than second");
          }else{
            System.out.println("Second is grreater");
          }
    }
    
}
