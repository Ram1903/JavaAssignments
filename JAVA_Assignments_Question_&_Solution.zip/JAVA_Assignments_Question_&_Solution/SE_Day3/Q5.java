package SE_Day3;
/*
 
5) accept a number and display its table using 
	while
	do... while
	for

 */
import java.util.Scanner;
public class Q5 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int n=sc.nextInt();
        int i=1;
        System.out.println("using while loop");
        while(i<=10){
            int a=n*i++;
            System.out.print(a+" ");
        }
        System.out.println();

        
        System.out.println("using do-while loop");
        int j=1;
        do{
            int a=n*j++;
            System.out.print(a+" ");
        }while(j<=10);
        System.out.println();

        System.out.println("Using for loop");
        for(int k=1;k<=10;k++){

            int ans=k*n;
            System.out.print(ans+" ");
        }
    }
    
}
