package SE_Day3;
/*
 1) accept marks from user. if marks are
	> 75  display "Distinction"
	> =60 and < =75 display "first class"
	> =45 and < 60 display "second class"
	>=35 and < 45 display "pass class"
	<35 display "fail"
 */
import java.util.Scanner;
public class Q1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your marks");
        int m=sc.nextInt();
        if(m>75){
            System.out.println("Distinction");
        }else if(m>=60){
            System.out.println("First Class");
        }else if(m>=45){
            System.out.println("Second class");
        }else if(m>=35){
            System.out.println("Pass class");
        }else{
            System.out.println("fail");
        }
    }
    
}
