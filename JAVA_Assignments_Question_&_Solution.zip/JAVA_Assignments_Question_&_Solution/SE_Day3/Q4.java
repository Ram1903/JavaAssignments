package SE_Day3;
//
import java.util.Scanner;
//4) accept 2 numbers and a character as operator ( + , - ,* , / , % ). Perform arithmetic according to the character entered.
public class Q4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two numbers");
        int a=sc.nextInt();
        int b=sc.nextInt();
        System.out.println("Enter operator");
        char c=sc.next().charAt(0);

        switch(c){
            case '+':System.out.println(a+b);break;
            case '-':System.out.println(a-b);break;
            case '*':System.out.println(a*b);break;
            case '/':System.out.println(a/b);break;
            default:System.out.println("Invalid input");break;
        }
    }
    
}
