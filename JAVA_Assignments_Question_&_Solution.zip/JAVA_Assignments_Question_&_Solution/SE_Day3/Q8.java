package SE_Day3;
//
import java.util.Scanner;
//8) create int array of 5 elements and accept 5 values inside it. Now display all the numbers of array.
public class Q8 {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int arr[]=new int[5];
        int l=arr.length;
        for(int i=0;i<l;i++){
            arr[i]=sc.nextInt();
        }
        for(int i=0;i<l;i++){
            System.out.print(arr[i]+" ");
        }
    }
    
}
