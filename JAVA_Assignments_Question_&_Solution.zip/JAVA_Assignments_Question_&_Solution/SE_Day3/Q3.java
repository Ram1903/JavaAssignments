package SE_Day3;
//
import java.util.Scanner;
//3) accept a character and display (using if.. else ) whether it is vowel or not.
public class Q3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a character");
        char a=sc.next().charAt(0);
        if(a=='a'||a=='e'||a=='i'||a=='o'||a=='u'){
            System.out.println("It's a vowel");
        }else{
            System.out.println("IT's not a vowel");
        }
    }
    
}
