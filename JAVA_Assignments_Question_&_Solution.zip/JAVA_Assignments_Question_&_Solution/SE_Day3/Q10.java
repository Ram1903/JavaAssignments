package SE_Day3;
/*
 
10) accept 5 numbers in an array and display their sum.
 */
import java.util.Scanner;
public class Q10 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 5 elements");
        int sum=0;
        for(int i=0;i<5;i++){
            int n=sc.nextInt();
            sum=sum+n;
        }
        System.out.println(sum);
    }
}
