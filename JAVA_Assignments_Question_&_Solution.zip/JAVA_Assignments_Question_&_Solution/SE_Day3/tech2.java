package SE_Day3;

public class tech2 {
    
    
    public static void main(String[] args) {  
        tech1 t1 = new tech1(); 
        static tech1 t3 = new tech1();  
        t1.demo();
        t3.demo();
    }
    
}
 class tech1 {
    public void demo(){
        System.out.println("Hello, World!");
    }
}
 class tech3 {
    public void demo(){
        System.out.println("Hello, World!");
    }
}

