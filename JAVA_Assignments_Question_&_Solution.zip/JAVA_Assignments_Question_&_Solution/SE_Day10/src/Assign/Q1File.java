package Assign;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * 
 write a file copy program using FileInputStream and FileOutputStream

	hint: existing file u need to open using FileInputStream and new file u need
 to open using FileOutputStream.

	first read existing file's data inside byte array and then write the same
 byte array inside new file.

	byte array should be created equivalent to the length of existing file.
 */
public class Q1File {
    public static void main(String args[]) {
        File inputFile = new File("d://Q1F.txt");
        File outputFile = new File("d://Q1Cp.txt");

        try (FileInputStream fis = new FileInputStream(inputFile);
             FileOutputStream fos = new FileOutputStream(outputFile)) {

          byte[] b1=new byte[((int)outputFile.length())];
          fis.read(b1);
          fos.write(b1);
            System.out.println("File copied successfully!");

        } catch (IOException e) {
            System.out.println( e.getMessage());
        }
        
    }
}

