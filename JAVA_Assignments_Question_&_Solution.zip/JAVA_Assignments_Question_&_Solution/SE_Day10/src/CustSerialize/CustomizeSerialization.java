package CustSerialize;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable{
	private String username="Ram";
	private String pwd="Yamraj";
	public void setUser(String username) {
		this.username=username;
	}
	public String getUser() {
		return username;
	}
	public void setpwd(String pwd) {
		this.pwd=pwd;
	}
	public String getpwd() {
		return pwd;
	}
}
public class CustomizeSerialization {
	public static void main(String args[]) throws Exception {
		Student st=new Student();
		
		FileOutputStream fos=new FileOutputStream("d://Student0");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(st);
		
		FileInputStream fis=new FileInputStream("d://Student0");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Student f1=(Student)ois.readObject();
		System.out.println(f1.getUser()+" "+f1.getpwd());
		
	}
}
