package Serialization2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class base //implements Serializable
{
	int num1=30;
	base(){
		System.out.println("Base constant");
	}
}
class sub1 extends base implements Serializable
{
	int num2=60;
	sub1(){
		System.out.println("sub Constant");
	}
}
public class se_dese {
	public static void main(String args[]) throws Exception {
		sub1 s=new sub1();
		s.num1=100;
		s.num2=200;
		System.out.println(s.num1+" "+s.num2);
		FileOutputStream FOS=new FileOutputStream("d://deser.txt");
		ObjectOutputStream OOS=new ObjectOutputStream(FOS);
		OOS.writeObject(s);
		OOS.close();
		s=null;
		FileInputStream FIS=new FileInputStream("d://deser.txt");
		ObjectInputStream OIS=new ObjectInputStream(FIS);
		sub1 ref=(sub1)OIS.readObject();
		//base ref=(base)OIS.readObject();
		System.out.println(ref.num1+" "+ref.num2);
	}
}
