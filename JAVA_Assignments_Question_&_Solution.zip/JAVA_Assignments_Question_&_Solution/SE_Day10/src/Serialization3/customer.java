package Serialization3;

import java.io.Serializable;

/*
 1)create a customer class with following attributes
	custid
	custname
	address
	age
create one instance of it and store it in a file. (Serialization).
now open a file, read the object and read its contents . (Deserialization)
 */
public class customer implements Serializable{
	public int custid;
	public String custName;
	public String addr;
	public int age;
}
