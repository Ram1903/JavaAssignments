package Serialization3;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class seCustomer {
	public static void main(String args[]) {
	customer c1=new customer();
	c1.custid=01;
	c1.custName="sanket";
	c1.addr="nashik";
	c1.age=32;
	
	String fn="d://customer.txt";
	try {
		FileOutputStream fos=new FileOutputStream(fn);
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(c1);
	}catch(IOException e) {
		System.out.println(e.getMessage());
	}
	
}
}