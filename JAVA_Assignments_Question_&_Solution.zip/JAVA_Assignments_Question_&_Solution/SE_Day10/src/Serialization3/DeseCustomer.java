package Serialization3;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeseCustomer {
	public static void main(String args[]) throws ClassNotFoundException {
		String fn="d://customer.txt";
		try {
			FileInputStream fis=new FileInputStream(fn);
			ObjectInputStream ois=new ObjectInputStream(fis);
			customer c1=(customer)ois.readObject();
			System.out.println(c1.custid);
			System.out.println(c1.custName);
			System.out.println(c1.addr);
			System.out.println(c1.age);
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
