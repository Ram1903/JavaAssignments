package Pract;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class fileHandle {
    public static void main(String[] args) {
    	try {
    		FileOutputStream fos=new FileOutputStream("d://abc.txt",true);
    		String data="Hello world abc";
    		fos.write(data.getBytes());
    	}catch(IOException e) {
    		System.out.println(e.getMessage());
    	}

    }
}
