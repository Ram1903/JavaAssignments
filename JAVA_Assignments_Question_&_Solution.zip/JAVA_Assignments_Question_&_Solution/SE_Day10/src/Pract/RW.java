package Pract;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class RW {
	public static void main(String args[]) {
		try(FileOutputStream fos=new FileOutputStream("d://fis")){
			try(DataOutputStream dos=new DataOutputStream(fos)){
				dos.writeInt(10);
				dos.writeByte(123);
				dos.writeBoolean(false);
				dos.writeDouble(4.4);
				dos.writeUTF("Hello");
			}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try(FileInputStream fis=new FileInputStream("d://fis")){
			try(DataInputStream dis=new DataInputStream(fis)){
				System.out.println(dis.readInt());
				System.out.println(dis.readByte());
				System.out.println(dis.readBoolean());
				System.out.println(dis.readDouble());
				System.out.println(dis.readUTF());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
