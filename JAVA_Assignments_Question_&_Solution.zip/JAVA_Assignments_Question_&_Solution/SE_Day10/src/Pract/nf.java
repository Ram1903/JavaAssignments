package Pract;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class nf {
    public static void main(String args[]) {
    	File a=null;
    	File b=null;
    	try {
    		a=new File("d://practicef10.txt");
    		if(a.createNewFile()) {
    			System.out.println("File is created");
    		}else {
    			System.out.println("File not created");
    		}
    	}catch(IOException e) {
    		System.out.println(e.getMessage());
    	}
    	
    	try {
    		FileOutputStream fos=new FileOutputStream("d://practicef10.txt"
    			,true);
    		String data="Hello world abc";
    		fos.write(data.getBytes());
    	}catch(IOException e) {
    		System.out.println(e.getMessage());
    	}
    	try {
    		b=new File("d://practicef11.txt");
    		if(b.createNewFile()) {
    			System.out.println("File is created");
    		}else {
    			System.out.println("File not created");
    		}
    	}catch(IOException e) {
    		System.out.println(e.getMessage());
    	}
    	FileInputStream fis=null;
    	FileOutputStream fos=null;
    	try {
    	if(b.exists()) {
    		fis=new FileInputStream(a);
    	}
    	}catch(IOException e) {
    		System.out.println(e.getMessage());
    	}try {
    	if(a.exists()) {
    		fos=new FileOutputStream(a);
    	}
    	}catch(IOException e) {
    		System.out.println(e.getMessage());
    	}
    	byte b1[]=new byte[(int)b.length()];
    	
    	try {
			fis.read(b1);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	try {
			fos.write(b1);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
}
