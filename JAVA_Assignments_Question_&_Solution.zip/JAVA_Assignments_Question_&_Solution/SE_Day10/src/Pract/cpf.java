package Pract;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class cpf {
	public static void main(String args[]) {
		char arr1[]=null;
		try(FileWriter fw=new FileWriter("d://fileek")){
			char arr[]= {'a','b','c','d'};
			fw.write(arr);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		char[] ss=null;
		try(FileReader fr=new FileReader("d://fileek")){
			arr1=new char[(int)new File("d://fileek").length()];
			fr.read(arr1);
			ss=arr1;
					
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int i=0;i<arr1.length;i++) {
			System.out.println(arr1[i]);
			System.out.println(ss[i]);
		}
		
	}
}
