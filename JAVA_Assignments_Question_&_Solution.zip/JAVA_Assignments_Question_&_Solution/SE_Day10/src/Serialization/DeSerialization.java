package Serialization;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeSerialization {
	public static void main(String args[]) {
		String fn="d://serialize2";
		try {
			FileInputStream fis=new FileInputStream(fn);
			ObjectInputStream ois=new ObjectInputStream(fis);
			
			Student obj=(Student)ois.readObject();
			System.out.println(obj.RollNo);
			System.out.println(obj.Name);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
