package Serialization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationDemo {
    public static void main(String args[]) {
    	Student s1=new Student();
    	s1.Name="Ram";
    	s1.RollNo=7;
    	
    	String fn="d://serialize2";
    	try {
    		FileOutputStream fos=new FileOutputStream(fn);
    		ObjectOutputStream oos=new ObjectOutputStream(fos);
    		oos.writeObject(s1);
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }
}
