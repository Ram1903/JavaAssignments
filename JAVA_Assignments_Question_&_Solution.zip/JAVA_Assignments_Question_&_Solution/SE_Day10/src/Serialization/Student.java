package Serialization;

import java.io.Serializable;

public class Student implements Serializable {
       public int RollNo;
       public String Name;
}
