package person;
/*
 
2) Person class implements Serializable with
	private String name
	private int age

		getters and setters
		parameterized constructor

Student extends Person
	private int rollno
		getter and setters
		parameterized constructor accepting name,age and rollno
			pass name and age to the super constructor

 */
public class person {

}
