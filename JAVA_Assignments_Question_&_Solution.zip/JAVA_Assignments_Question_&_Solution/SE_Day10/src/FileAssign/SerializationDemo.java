package FileAssign;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationDemo {
    public static void main(String args[]) throws Exception {
    	Student s1=new Student();
    	s1.Name="Ram";
    	s1.RollNo=7;
    	
    	String fn="d://serialize1";
    	try {
    		FileOutputStream fos=new FileOutputStream(fn);
    		ObjectOutputStream oos=new ObjectOutputStream(fos);
    		oos.writeObject(s1);
    		System.out.println("Success");
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
    	String ri="d://serialize1";
    	FileInputStream fis=new FileInputStream(ri);
    	ObjectInputStream ois=new ObjectInputStream(fis);
    	Student obj=(Student)ois.readObject();
    	System.out.println(obj.Name);
    	System.out.println(obj.RollNo);
    	}
}
