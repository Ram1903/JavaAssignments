package FileAssign;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/*
 1)accept 10 characters from a user ( use Scanner).store these 10 characters in a file. (FileWriter)Now open a file and read all these characters.
 */
public class Q1 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		String a=sc.next();
		char[] b=null;

		char arr[]=new char[10];
		
		arr=a.toCharArray();
		try(FileWriter rw=new FileWriter("d://Q1File")) {
			rw.write(arr);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try(FileReader fr=new FileReader("d://Q1File")){
			fr.read(arr);
			b=arr;
			for(int i=0;i<10;i++) {
				System.out.println(arr[i]);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(b);
	}
}
