package FileAssign;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class Q2 {
	public static void main(String args[]) throws IOException {
		File f1=new File("d://Q222");
		File f2=new File("d://Q2cp22");
		
		if(f2.exists()) {
			FileOutputStream fos=new FileOutputStream(f1);
			int s=123;
			fos.write(s);
			FileInputStream fis=new FileInputStream(f2);
			
			byte b1[]=new byte[(int)f2.length()];
			 fis.read(b1);
			 fos.write(b1);
		}
		
	}
}
