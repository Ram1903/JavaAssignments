package FileAssign;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

////
//4) Write a file copy program using unicode character streams.
//( FileWriter and FileReader )
public class Q4 {

	public static void main(String args[]) {
		try 
			(FileReader fr=new FileReader("d://fileread.txt");
				FileWriter fw=new FileWriter("d://filewrite.txt");
					)
				{
			int character;
			while((character=fr.read())!=-1) {
				fw.write(character);
				
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		try {
			FileReader fre=new FileReader("d://filewrite.txt");
			ObjectOutputStream oos=new ObjectOutputStream(fre);
		}
	}
}
