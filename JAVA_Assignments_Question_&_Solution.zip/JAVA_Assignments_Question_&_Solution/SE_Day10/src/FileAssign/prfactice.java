package FileAssign;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.RandomAccessFile;
import java.util.*;
/*

3) write a file copy program using byte streams.
( FileOutputStream and FileInputStream )
 */

public class prfactice{
	public static void main(String args[]) {
		
		try {
		    FileWriter fw=new FileWriter("d://fwn.txt");
		    String s="hello new file";
		    fw.write(s);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		try (
			FileWriter fw=new FileWriter("d://frn.txt");
			FileReader fr=new FileReader("d://fwn.txt");){
			int character;
			while((character=fr.read())!=-1) {
				fw.write(character);
			}
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		try {
			FileReader fr=new FileReader("d:frn.txt");
			int character;
			while((character=fr.read())!=-1) {
				System.out.print(character);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}