// package SE_Day4;
// /*
//  7)	Define a parent and a child class . Now explain function overriding with Example.
//  */
// class A{
//     Object display(){
//        int a=10;
//        System.out.println(a);
//         return a;
//     }
// }
// class B extends A{
//    String display(){
//     return toString();
//    }
// }
// public class Q7 {
//     public static void main(String[] args) {
//         B b=new B();
//     }
// }
