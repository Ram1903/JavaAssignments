package SE_Day4;
/*
 1)	Define 2 classes “First” and “Second” with member variables , member functions and constructors of  your choice. Now define a class “Two” in which define main function . In main function create various instances of First and Second  and call their individual member functions.
 */

class first{

    int num=10;
    first(){
        System.out.println(num);
        System.out.println("parent class");
    }
}
class second extends first{
    int num2=20;
    public void A(){

        System.out.println("method");
    }
    second(){
        System.out.println(num2);
        System.out.println("Child class");
        A();
        


    }
}

public class Q1 {

    //static second s1=new second();
    public static void main(String[] args) {
        System.out.println(" ");
        second s1=new second();
        s1.A();
      
    }
    
}