package SE_Day4;
/*
 
4)	Show the example of single level inheritance with constructor invocation.

//  */
// class A{
//      int a=10;
//      A(){
//         System.out.println(a);
//      }
// }
// class B extends A{
//     int b=20;
//     B(){
//         System.out.println(b);
//     }

// }
// public class Q4 {
//     public static void main(String[] args) {
//         System.out.println(" ");
//         B b=new B();
//     }
// }
