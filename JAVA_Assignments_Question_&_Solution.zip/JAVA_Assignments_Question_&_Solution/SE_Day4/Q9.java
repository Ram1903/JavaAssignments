package SE_Day4;
/*
 
9)	Define a class “Shape” with “draw()” function . Now derive  classes like “Circle”, “Polygon”,”Rectangle” etc. from “Shape” and override “draw()” function. Define a class “ShapeDemo” in which  write  main()  function. In the main function create a reference to Shape class referring to any of the sub class. Using this reference, call “draw()” and check the result.

 */
class Shape{
    void draw(){

        System.out.println(1);
    }
}
class circle extends Shape{
    void draw(){
        System.out.println(2);        
    }

}
class Polygon extends Shape{
    void draw(){
        System.out.println(3);        
    }

}
class rectangle extends Shape{
    void draw(){
        System.out.println(4);
    }
}

public class Q9 {
    public static void main(String[] args) {
        System.out.println(" ");
        Shape s=new Polygon();
        s.draw();
        
    }
    
}
