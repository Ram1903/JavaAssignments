// package SE_Day4;
// /*
//  * 
//  Define a parent class with one function. Define child class with the function having same name as of parent class function, but having different argument.
// Create an instance of child class and call the functions. Make sure u have followed the concept of “function overloading “ in inheritance.

//  */
// class A{
//     int n=9;
//     String c="hi";
//     public void displ(int a){
//         a=n;
//         System.out.println(a);
//     }

// }
// class B extends A{
//     public void displ(String a){
//         a=c;
//         System.out.println(a);
//     }

// }
// public class Q8 {
//     public static void main(String[] args) {
//         B b=new B();
//         b.displ(5);
//     }
    
// }
