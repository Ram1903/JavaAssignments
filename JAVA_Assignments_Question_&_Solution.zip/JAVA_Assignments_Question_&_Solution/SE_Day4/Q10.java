package SE_Day4;
/*
 10)	Define an interface “Vechicle” with “start()” function . Now derive  classes like “TwoWheeler”, “ThreeWheeler”,”FourWheeler” etc. from “Vehicle” and override “start()” function. Define a class “VDemo” in which  write  main()  function. In the main function create a reference to Vehicle  class referring to any of the sub class. Using this reference, call “start" method.
 */
class animal{
public String name="Tarun";
public int age=26;
public int c=1;

  animal(String n,int a){
    n=name;
    a=age;

    System.out.println("Parent class");
  }
}
class Dog extends animal{

    Dog(String name,int c){
        super(name,c);
        System.out.println("Child class");
    }
}

public interface Q10 {

    public static void main(String[] args) {
        animal a=new animal(null, 0);
        Dog d=new Dog("tarun",26);
        
    }
    
} 