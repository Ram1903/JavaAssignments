package SE_Day4;
/*
 3)	Define a class “Check” in which declare member variables using  different accessibility modifiers i.e.  <default>, private ,public and protected.   Define a function “disp”  which should be public.  Define a class “CheckDemo” in which you will write “main()” function. Create an instance of  the class “Check” and  show how many  variables can be accessed directly and how many indirectly.
 */
class check{
    
    private int a=10;
    protected int b=20;
    int c=30;
    public int d=40;


    public void disp(){

         System.out.println(a);
        // System.out.println(b);
        // System.out.println(c);
        // System.out.println(d);
        
    }
}
public class Q3 {
    public static void main(String[] args) {
        System.out.println(" ");
        check cf=new check();
        cf.disp();
        System.out.println(cf.b);
        //System.out.println(cf.a);
        System.out.println(cf.c);
        System.out.println(cf.d);

    }
    
}
