package SE_Day4;
/*
 
5)	Show the example of multi-level inheritance with constructor invocation.

//  */
// class A{
//     int a=10;
//     A(){
//        System.out.println(a);
//     }
// }
// class B extends A{
//    int b=20;
//    B(){
//        System.out.println(b);
//    }

// }
// class C extends B{
//     int c=40;
//     C(){
//         System.out.println(c);
//     }
// }
// public class Q5 {
//    public static void main(String[] args) {
//        System.out.println(" ");
//        B b=new B();
//        C c=new C();
//    }
// }
