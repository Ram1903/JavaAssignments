package SE_Day4;
/*
 2)	Create a class with static and non-static member variables. Define static and non-static member functions. Create instance of this class and call both static and non-static member functions.
 */
class my{
    {
        System.out.println("Non static2");
    }
    static int a=10;
    int b=20;
    void B(){
        System.out.println("non Static");
        System.out.println(a);
        System.out.println(b);
    }
   static void A(){
    System.out.println("Static");
        System.out.println(a);
       
    }
    static{
        System.out.println("static2");
    }
    
}
public class Q2 {
    public static void main(String[] args) {
        System.out.println(" ");
        my obj=new my();
        obj.B();
        obj.A();
       

    }
    
}
