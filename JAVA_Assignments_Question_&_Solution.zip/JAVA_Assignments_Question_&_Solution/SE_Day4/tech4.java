package SE_Day4;

class Animal{
    void voice(){
        System.out.println("Voice");
    }
}
class Shashwat extends Animal{
    void voice(){
        System.out.println("Aaai dukhte");
    }
}
class aniket extends Animal{
    void voice(){
        System.out.println("Baasi");
    }
}
class tarun extends Animal{
    void voice(){
        System.out.println("Delhi se he b*");
    }
}
public class tech4{
    public static void main(String[] args) {
        System.out.println(" ");
        Animal obj=new Shashwat();
        obj.voice();
    }
}