package A_Assign;

import Assign.Q2;

/*
 1) create a multi-threaded application by using Thread pool.create 2 threads. each thread should display characters 
 from A to J. [ make sure while one thread executes , other thread should not interfere ]
 
 */
public class Q1 implements Runnable{

	synchronized public void run() {
		// TODO Auto-generated method stub
		for(char i=65;i<75;i++) {
    		System.out.print(i+" ");
    	}
		
	}

	public static void main(String args[]) {
		Q1 ob=new Q1();
		Thread a=new Thread(ob);
		Thread b=new Thread(ob);
		a.start();
		b.start();
	}
}
