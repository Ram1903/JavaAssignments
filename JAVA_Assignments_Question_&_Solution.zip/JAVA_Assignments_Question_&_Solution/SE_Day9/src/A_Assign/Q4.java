package A_Assign;

import java.util.concurrent.locks.ReentrantLock;

public class Q4 implements Runnable{
	ReentrantLock myLock=new ReentrantLock();
	synchronized public void run() {
		for(int i=0;i<3;i++) {
			System.out.println("Status "+i);
			try {
				myLock.lock();
				Thread.sleep(100);
			}catch(InterruptedException e) {
				e.getMessage();
			}
		}
	}
	
	public static void main(String args[]) {
		Q4 a=new Q4();
		Thread t=new Thread(a);
		Thread t2=new Thread(a);
		t.start();
		t2.start();
		
	}

}
