package A_Assign;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

/*
 

3) create a multi-threaded application by using Thread pool and ReentrantLock 
(explicit locking) .create 2 threads. each thread should display characters from A to J.
 [ make sure while one thread executes , other thread should not interfere ]


 */
class Hello implements Runnable{
	ReentrantLock lock=new ReentrantLock();
	synchronized public void run() {
		lock.lock();
		try {
		for(char i=65;i<75;i++) {
			System.out.print(i+" ");
		}
		}finally {
			lock.unlock();
		}
	}
}
public class Q3_ {
	

	
	public static void main(String args[])  {
		//ExecutorService exe=Executors.newCachedThreadPool();

		ExecutorService exe=Executors.newSingleThreadExecutor();
		exe.execute(new Hello());
        exe.execute(new Hello());
        exe.shutdown();
	}
}
