package A_Assign;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class wow implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		perform();
	}
	public void perform() {
		for(int i=0;i<3;i++) {
			System.out.println("Hello "+i+Thread.currentThread());
			try {
				Thread.sleep(100);
			}catch(InterruptedException e) {
				System.out.print(e);
			}
		}
	}
	
}
public class Q3{
	public static void main(String args[] ){
		ExecutorService exe=Executors.newCachedThreadPool();
		
		for(int i=0;i<3;i++) {
			exe.execute(new wow());
			
		}
		exe.execute(new wow());
		exe.shutdown();
	}
}