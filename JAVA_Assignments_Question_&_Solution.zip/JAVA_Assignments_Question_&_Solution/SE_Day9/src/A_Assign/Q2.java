package A_Assign;

import java.util.concurrent.*;
/*
 
2) create a multi-threaded application by using Thread pool.create 2 threads. each thread should display numbers from 1 to 10. [ make sure while one thread 
executes , other thread should not interfere ]
Also when first thread displays nos. from 1 to 5 it should released the lock and allow other thread to display nos. from 1 to 5 and then previous thread will 

display nos. from 6 to 10 and so on.


 */

public class Q2 implements Runnable{
	static Class cs;
	 static void disp1()
	 {
		synchronized(cs)
		{
		for(int i=1;i<=10;i++)
		{
        if(i==6)
	{
		try
		{
			cs.wait(10);
		}
		catch(InterruptedException ie)
		{
		}
	}
         System.out.print(i+" ");
         System.out.println(Thread.currentThread()+" ");
		}
		}
	}
	
	public void run()
	{
		disp1();
	}
	public static void main(String args[])throws Exception
	{
		cs=Class.forName("A_Assign.Q2");
		Q2 c=new Q2();
		Q2 c1=new Q2();
		Thread t1=new Thread(c);
		Thread t2=new Thread(c1);
		t1.start();
		t2.start();
	}
}
