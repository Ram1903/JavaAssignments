package Zip;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class wow implements Runnable{
	@Override
	synchronized public void run() {
		// TODO Auto-generated method stub
		perform();
	}
	public void perform() {
		for(int i=0;i<5;i++) {
			System.out.println("Static "+i+ Thread.currentThread());
		}
	}
}
public class pract {


     
	public static void main(String args[]) {
		ExecutorService exe=Executors.newFixedThreadPool(1);
		for(int i=0;i<3;i++) {
			exe.execute(new wow());
		}
	}
}
