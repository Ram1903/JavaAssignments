package Assign;
/*
 
4)create 2 threads. Write a program which displays number 1 to 10 using class lock. 
[hint:- use "implements Runnable" and synchronized block]
 */
public class Q4 implements Runnable{
    public void run() {
    	synchronized(Q4.class){
    	 for(int i=1;i<=10;i++) {
    		 System.out.print(i+" ");
//    		 try {
//    			 Thread.sleep(15);
//    		 }catch(InterruptedException e) {
//    			 System.out.println(e.getMessage());
//    		 }
    	 }}
     }
     public static void main(String args[]) {
    	 Q4 ob=new Q4();
    	 Thread a=new Thread(ob);
    	 Thread b=new Thread(ob);
    	 a.start();
    	 b.start();
     }
}
