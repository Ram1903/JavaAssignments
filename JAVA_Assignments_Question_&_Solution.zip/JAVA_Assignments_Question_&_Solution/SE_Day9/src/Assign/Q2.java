package Assign;
/*
 1) create a multi-threaded application by using  "extends Thread " method.create 2 threads. they should display characters from A to J.

2) above program  using "implements Runnable" method.
 */
public class Q2 implements Runnable{

	@Override
	synchronized public void run() {
		// TODO Auto-generated method stub
		for(char i=65;i<75;i++) {
    		System.out.println(i);
    	}
		
	}

	public static void main(String args[]) {
		Q2 ob=new Q2();
		Thread a=new Thread(ob);
		Thread b=new Thread(ob);
		a.start();
		b.start();
	}
}
