package Assign;
/*
 3) create 3 threads in such a way that while one thread is executing, 2 threads cannot interfere. they should display output "Exec  0" to "Exec 5".

 */
public class Q3 extends Thread{
	synchronized public void run() {
		for(int i=0;i<=5;i++) {
			System.out.println("Exec "+i);
//			try {
//				Thread.sleep(200);
//			}catch(InterruptedException e) {
//				System.out.println(e.getMessage());
//			}
		}
	}
	
	public static void main(String args[]) {
		Q3 ob=new Q3();
		Thread a=new Thread(ob);
		Thread b=new Thread(ob);
		Thread c=new Thread(ob);
		a.start();
		b.start();
		c.start();
	}

}
