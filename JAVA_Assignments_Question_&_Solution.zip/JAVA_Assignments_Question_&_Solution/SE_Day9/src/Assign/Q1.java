package Assign;
/*
 1) create a multi-threaded application by using  "extends Thread " method.create 2 threads. they should display 
 characters from A to J.

 */
public class Q1 extends Thread {
     synchronized public void run() {
    	for(char i=65;i<75;i++) {
    		System.out.println(i);
//    		try {
//    			Thread.sleep(200);
//    		}catch(InterruptedException e) {
//    			System.out.println();
//    		}
    	}
    }
    
	
	private void Synchronized(Q1 q1) {
		// TODO Auto-generated method stub
		
	}

	public static void main(String args[]) {
		Q1 w1=new Q1();
		Thread a=new Thread(w1);
		Thread b=new Thread(w1);
		a.start();
		b.start();
	}
}
