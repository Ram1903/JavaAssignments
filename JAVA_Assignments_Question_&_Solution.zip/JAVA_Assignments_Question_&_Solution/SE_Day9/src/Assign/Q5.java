package Assign;
/*
 
5) create 2 threads
	one thread will display 1 to 50
	second thread will display 50 to 1
both the threads should start simultaneously.

(use implements method)
 */
public class Q5 extends Thread {
	public int v=1;
	public void run() {
		if(v<50) {
			for(int i=v;i<=50;i++) {
				System.out.print(i+" ");
				v++;
			}
		}else {
			for(int i=v;i>=1;i--) {
				System.out.print(i+" ");
			}
		}
	}
	public static void main(String args[]) {
		Q5 ob=new Q5();
		Thread a=new Thread(ob);
		Thread b=new Thread(ob);
		a.start();
		b.start();
	}

}
