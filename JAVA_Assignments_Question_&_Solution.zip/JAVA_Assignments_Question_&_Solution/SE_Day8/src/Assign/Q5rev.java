package Assign;

public class Q5rev {

}
