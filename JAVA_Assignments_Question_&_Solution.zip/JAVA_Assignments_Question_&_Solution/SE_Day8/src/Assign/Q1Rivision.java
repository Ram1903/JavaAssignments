package Assign;
/*
 Revision_1) 
Define a class “MyClass”. Define a class “Everything” and define a member function with variable no. 
of argument inside it. Define  a 
class Demo1  and define main function in it. From main
 function , call the function of class Everything and make sure you can pass any arguments , it will 
 take and display. It should even 
 take instance of “MyClass” and display.

 */
class MyClass{
	public int disp(int a) {
		return a;
		
	}

	
	
}
class Everything extends MyClass{
	public int disp(int a) {
		
       return a;
		
	}
}
public class Q1Rivision {
   public static void main(String[] args) {
	//MyClass obj=new Everything();
	  Everything obj=new Everything();
	//obj.disp();
	obj.disp(5);
}
}
