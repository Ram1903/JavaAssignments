package Assign;
/*
 
Revision_3) 
create 4 classes A,B,C,D with member functions Afun(),Bfun(),Cfun() and Dfun() respectively.
now define "Demo" class with main function. Inside main function create array of Object class which will store instances
 of above mentioned classes. Traverse through this array and call "Cfun()" of class C only.

 */
class A{
	A(){
		System.out.println("A");
	}
	void Afun(){
		System.out.println("AFUN called");
	}
}
class B{
	B(){
		System.out.println("B");
	}
     void Bfun(){
		System.out.println("Bfun Called");
	}
}
class C{
	C(){
		System.out.println("C");
	}
     void Cfun(){
		System.out.println("CFun Called");
	}
}
class D{
	D(){
		System.out.println("D");
	}
     void Dfun(){
		System.out.println("Dfun Called");
	}
}
public class Q3rev {
public static void main(String args[]) {

    Object[] objects = {new A(), new B(), new C(), new D()};
    for (Object obj : objects) {
        if (obj instanceof C) {
            ((C) obj).Cfun();
        }
    }
}
}
