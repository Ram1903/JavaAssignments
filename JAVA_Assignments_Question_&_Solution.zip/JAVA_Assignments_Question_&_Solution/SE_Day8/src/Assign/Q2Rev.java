package Assign;
/*
 
Revision_2)
Define a class Sample with member variable “char ch” and a parameterized constructor. Create some 
instances(at least 2) of this class by passing any alphabet.  Now achieve following tasks:

a) when you print the reference it should be display the character which was passed during instantiation.
b) if two instances have same character or an alphabet, their "equals()" should return true and obviously "hashCode()"
 also should be same.


 */

class Sample {
    char ch;

    Sample(char c) {
        this.ch = c;
    }

    @Override
    public String toString() {
        return Character.toString(ch);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Sample sample = (Sample) obj;
        return ch == sample.ch;
    }

    @Override
    public int hashCode() {
        return Character.hashCode(ch);
    }
}

public class Q2Rev {
    public static void main(String[] args) {
        Sample[] string = new Sample[5];
        string[0] = new Sample('a');
        string[1] = new Sample('b');
        string[2] = new Sample('c');
        string[3] = new Sample('d');
        string[4] = new Sample('a');

        for (Sample s : string) {
            System.out.println(s);
        }

        System.out.println("string[0] equals string[4]: " + string[0].equals(string[4]));
        System.out.println("string[0] hashCode: " + string[0].hashCode());
        System.out.println("string[4] hashCode: " + string[4].hashCode());
    }
}

