package Assign;
/*
 
Revision_4) 
create a parent class "Artist" with a member function "void perform()".
now derive following child classes from "Artist"
	Actor,Singer and Musician and override "perform" in these classes to write the specific task.
inside "Actor" class define one more method
	void changeGateUp()
	{
		S.o.p("as per the role demands");
	}

now create a Demo class with main function.
inside main function create array of "Artist" with size 3.
store instances of the above child classes in it.
Now traverse through the array and invoke "perform" of each child class. In addition to this wherever "Actor" object is
 there inside the array , also perform "changeGateUp()" method.

 */
class Artist{
	void perform() {
	}
}
class Actor extends Artist{
	void  perform() {
		System.out.println("Actor");
		
	}
	void changeGateUp()
	{
		System.out.println("as per the role demands");
	}
}
class Singer extends Artist{
	void  perform() {
		System.out.println("Singer");
		
	}
}
class Musician extends Artist{
	void  perform() {
		System.out.println("Musician");
		
	}
}
public class Q4rev {
    public static void main(String args[]) {
    	Artist arr[]=new Artist[3];
    	arr[0]=new Actor();
    	arr[1]=new Singer();
    	arr[2]=new Musician();
    	
    	for(Artist on:arr) {
    		on.perform();
    		if(on instanceof Actor) {
    			((Actor) on).changeGateUp();
    			}
    	}
    }
}
