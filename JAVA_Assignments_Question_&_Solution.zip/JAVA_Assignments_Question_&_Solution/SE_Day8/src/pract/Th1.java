package pract;

public class Th1 extends Thread{
	 public void run()	{
		//synchronized (this){
		
    	 for(int i=0;i<5;i++) {
    		 System.out.println("Hello"+i);
    		 System.out.println(Thread.currentThread());
    		 System.out.println(Thread.currentThread().getName());
    	 }

		
		} 
    // }
     public static void main(String args[]) {
//    	 Th1 ob=new Th1();
//    	 Thread t1=new Thread(ob);
//    	 Thread t2=new Thread(ob);
//    	 t1.start();
//    	 t2.start();
    	 Th1 ob=new Th1();
    	 Thread t1=new Thread(ob);
    	Thread t2=new Thread(ob);
    	 t2.start();
    	 t1.start();
     }
}
