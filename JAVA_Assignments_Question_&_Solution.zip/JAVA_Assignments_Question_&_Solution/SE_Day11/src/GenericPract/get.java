package GenericPract;

public class get {
	public static void main(String args[]) {
		set Set=new set("Wow");
		System.out.println(Set.getval());
		
	}
}
