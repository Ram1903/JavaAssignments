package GenericPract;

import java.util.ArrayList;
import java.util.List;

public class Demo {
	public static void main(String args[]) {
		//here if we write other than integer it shows error on compile time this conceppt is generic
		
		List<Integer> List=new ArrayList<>();
		List.add(101);
		
		List newList=new ArrayList();
		newList.add("Hello");
		newList.add(11);
		
		System.out.println(List);
		System.out.println(newList);
	}
}
