package GenericPract;

public class set {
	Object container;
	public set(Object Container) {
		
		this.container=container;
	}
	public Object getval() {
		return this.container;
	}
}
