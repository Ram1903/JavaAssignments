/**
 * 
 */
/**
 * 
 */
module Day11 {
	requires java.base;
}