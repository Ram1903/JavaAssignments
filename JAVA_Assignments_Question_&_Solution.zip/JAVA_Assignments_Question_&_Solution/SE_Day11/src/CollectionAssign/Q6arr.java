package CollectionAssign;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/*
 * 
6) create a class "MyClass".
create 5 different objects of it.
add them in a ArrayList.
store ArrayList in file.
Now open a file, read ArrayList and display all objects.
 */
class MyClass implements Serializable{

	public int num;
	MyClass(int num){
		this.num=num;
	}
	public int getNum() {
		return num;
	}
	public String toString() {
		return "MyClass [num=" + num + "]";
	}
	}

public class Q6arr {
	public static void main(String args[]) {
		MyClass a=new MyClass(3);
		MyClass b=new MyClass(4);
		MyClass c=new MyClass(5);
		MyClass d=new MyClass(6);
		
		ArrayList<MyClass> list=new ArrayList<>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		
		try {
			FileOutputStream fis=new FileOutputStream("d://Q6file");
			ObjectOutputStream oos=new ObjectOutputStream(fis);
			oos.writeObject(list);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		try {

			FileInputStream fis=new FileInputStream("d://Q6file");
			ObjectInputStream ois=new ObjectInputStream(fis);
			//System.out.println(list);
			for(MyClass obj:list) {
				System.out.println(obj);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
