package CollectionAssign;

import java.util.LinkedList;
import java.util.List;

/*
 
2) on the developer side:
	create a generic class which can accept any type
		with setters , getters and toString methods.
	create necessary jar files and  documentation.

on client side 
	create the object of above generic class and invoke its setters , getters and display the object.
 */

public class Q2Dev <T>{
	public T first;
	void setval(T first) {
		this.first=first;
	}
	T getVal() {
		return this.first;
	}
	void show() {
		System.out.println(this.first);
	}
}
