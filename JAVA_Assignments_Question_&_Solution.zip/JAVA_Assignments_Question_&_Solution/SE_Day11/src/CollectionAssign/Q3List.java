package CollectionAssign;

import java.util.LinkedList;
import java.util.List;

/*
3) create LinkedList with the values 10,20,30 and 40.
display it.
now insert 500 in the beginning.
	insert 400 at 2nd position.
	add 1000 at the end.
display the list again.
 */
public class Q3List {
	public static void main(String args[]) {
		List<Integer> list=new LinkedList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		
		list.addFirst(500);
		list.add(1, 400);
		list.addLast(1000);
		System.out.println(list);
	}
}
