package CollectionAssign;

import java.util.LinkedList;
import java.util.List;
import java.util.*;

/*
 1) accept 10 numbers from user and add them inside the ArrayList.
using ListIterator display all the numbers bidirectionally.

 */
public class Q1add {
	public static void main(String args[] ){
		Scanner sc=new Scanner(System.in);
		List <Integer> li=new LinkedList<>();
		for(int i=0;i<10;i++) {
			int a=sc.nextInt();
			li.add(a);
			}
		ListIterator<Integer> lit=li.listIterator();
		while(lit.hasNext()) {
			System.out.print(lit.next()+" ");
		}
		System.out.println();
		while(lit.hasPrevious()) {
			System.out.print(lit.previous()+" ");
		}
	}
}
