package CollectionAssign;
/*
 
8) create a hierarchy as follows
	interface Game- play() method
	Derive at least 3 classes from it. ( Cricket, Chess and Football )
Now Create generic class which can take Game type (i.e. any sub type of Game) as parameter.
In this class try to call the play() method of the class which is passed to it.

 */
interface Game{
	void play();
}
class cricket implements Game{
	public void play() {
		System.out.println("cricket");
	}
}
class chess implements Game{
	public void play() {
		System.out.println("chess");
	}
}
class football implements Game{
	public void play() {
		System.out.println("football");
	}
}
class gameplay<T extends Game>{
	private T Game;
	public gameplay(T Game) {
		this.Game=Game;
	}
	public void playgame(){
		Game.play();
	}
}
public class Q8assi {
	 public static void main(String[] args) {
	        gameplay<cricket> cricketPlayer = new gameplay<>(new cricket());
	        cricketPlayer.playgame(); 
	        
	        gameplay<chess> chessplay=new gameplay<>(new chess());
	        chessplay.playgame();
	        
	        gameplay<football> footballplay=new gameplay<>(new football());
	        footballplay.playgame();
}
}