package CollectionAssign;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

/*
 
7) create a HashMap.
store  prn no. and students name of 10 students inside the HashMap.
now write this HashMap inside the file and read also. After reading display it using iterator.

 */
class Student{
	public int p;
	public String name;
	void student(int p,String name){
		this.p=p;
		this.name=name;
	}
	int getprn() {
		return this.p;
	}
	String getname() {
		return this.name;
	}
}
public class Q7as {
	public static void main(String args[]) {
		HashMap<Integer , String> stud=new HashMap<>();
		stud.put(01, "tarun");
		stud.put(02, "shashwat");
		stud.put(03, "Aniket");
		stud.put(04, "sanket");
		stud.put(05, "Devesh");
		try {
			FileOutputStream fos=new FileOutputStream("d://Q7assi.txt");
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			oos.writeObject(stud);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		try {
			FileInputStream fis=new FileInputStream("d://Q7assi.txt");
			ObjectInputStream ois=new ObjectInputStream(fis);
			
			//ois.readObject(stud);
			System.out.println(stud);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		}
}
