package CollectionAssign;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/*
 
4) add 5 numbers inside CopyOnWriteArrayList and show how can you add one more number at the same time of traversal through its iterator.
 */
public class Q4cor {
	public static void main(String args[]) {
		CopyOnWriteArrayList<Integer> list=new CopyOnWriteArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);

        Iterator<Integer> iterator = list.iterator();
        while(iterator.hasNext()) {
        	 Integer value = iterator.next();
        	
        	if (value == 1) {
                list.add(2,40);  
            }
        }
        System.out.println(list);
	}
}
