package CollectionAssign;

import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/*
 5) create a class MyNum with
		private int num;
		parameterized constructor

	
Demo class with main
	create 4 objects of MyNum by passing different integers.
	store these 4 objects inside "ArrayList"
	and now store that ArrayList inside file system.
	
	read ArrayList from file and traverse it using Iterator.
 */

class myNum implements Serializable{
	 private int num;

	    public myNum(int num) {
	        this.num = num;
	    }

	    public int getNum() {
	        return num;
	    }
}
public class Q4Demo {
	public static void main(String args[]) {

		List<myNum> list=new ArrayList<>();
		list.add( myNum(1));
		list.add( myNum(3));
		list.add( myNum(5));
		list.add( myNum(2));
		
		
	}


}
