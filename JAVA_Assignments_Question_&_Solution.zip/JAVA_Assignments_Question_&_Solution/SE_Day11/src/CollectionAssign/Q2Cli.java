package CollectionAssign;
/*

2) on the developer side:
	create a generic class which can accept any type
		with setters , getters and toString methods.
	create necessary jar files and  documentation.

on client side 
	create the object of above generic class and invoke its setters , getters and display the object.
 */
public class Q2Cli {
	public static void main(String args[]) {
		Q2Dev<String> g=new Q2Dev<>();
		g.setval("Hello");
		System.out.println(g.getVal());
		
		Q2Dev<Integer> h=new Q2Dev<>();
		h.setval(100);
		h.show();
	}
}
