/**
 * 
 */
/**
 * 
 */
module Day6 {
}