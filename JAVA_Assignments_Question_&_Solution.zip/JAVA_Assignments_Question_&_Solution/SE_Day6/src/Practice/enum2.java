package Practice;
enum colors{
	RED,YELLOW,BLACK,GREEN;
}
class get{
	public void getcolor(colors cr) {
		switch(cr) {
		case BLACK:System.out.println("BLACK color");break;
		case RED:System.out.println("RED color");break;
		case GREEN:System.out.println("GREEEN color");break;
		default:System.out.println("Invalid input");
		}
	}
}
public class enum2 {
	public static void main(String args[]) {
		get ref=new get();
		ref.getcolor(colors.BLACK);
		ref.getcolor(colors.RED);
		ref.getcolor(colors.GREEN);
	}
}
