package Practice;

import java.net.MulticastSocket;


//enum are often used to define a collection of constant values AND String
enum Status{
	Running, stop, pending, success, failed;
	}
	enum sample{
		member1;
		void disp1() {
			System.out.println("Display1 in enum sample");
		}
		void disp2() {
			System.out.println("Display2 in enum sample");
		}
	}

public class enum1 {
	public static void main(String[] args) {
		//status s=status.Running;
		//System.out.println(s);
		//System.out.println(s.ordinal());
		sample staus=sample.member1;
		staus.disp1();
		staus.disp2();
	}

}
