package Practice;
interface base{
	void disp();
}



public class pes {
		static base sub() {
			return new base(){
				public void disp() {

					System.out.println("in disp");
				}
				
			};
			
		}
public static void main(String args[]) {
	base e1=pes.sub();e1.disp();
	}
}
