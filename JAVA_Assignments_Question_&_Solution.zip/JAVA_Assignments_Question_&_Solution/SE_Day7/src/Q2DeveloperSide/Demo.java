package Q2DeveloperSide;

import Q2ClientSide.MyMath;

public class Demo {
	 public static void main(String[] args) {
	        MyMath math = new MyMath();
	        
	        try {
	            math.disp(21); 
	            math.disp(20); 
	        } catch (NumberNotDivisibleBySevenException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	
}
