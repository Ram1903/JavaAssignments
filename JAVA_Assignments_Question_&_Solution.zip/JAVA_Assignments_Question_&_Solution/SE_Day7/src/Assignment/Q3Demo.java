package Assignment;
import java.util.*;
/*
3) define "MyException" as a checked exception.

define a class "Demo" with 
	public void show1(), public void show2() , public void show3() and main functions.

inside "show3()" accept a number and if it is greater than 10 raise "MyException" else display the number.
	[ this method shouldn't handle the exception]

main() function should call "show1()" , 
show1() function should call "show2()",
show2() function should call "show3()"

show2() should not handle the exception but show1() should handle.

*/
class Demo{
	public void show1() {
		 try {
	            show2();
	        } catch (Q3MyException e) {
	            System.out.println("Exception handled in show1(): " + e.getMessage());
	        }
	}
public void show2()  throws Q3MyException{
	 show3();
	}
public void show3() throws Q3MyException {
	Scanner scanner = new Scanner(System.in);
    System.out.print("Enter a number: ");
    int number = scanner.nextInt();

    if (number > 10) {
        throw new Q3MyException("Number is greater than 10: " + number);
    } else {
        System.out.println("The number is: " + number);
    }
}
}
public class Q3Demo {
   public static void main(String args[]) throws Q3MyException {
	   Demo demo = new Demo();
       demo.show1();
   }
}
