package Zip.java;
import java.io.*;

import java.io.IOException;
public class HandleException
{
	void disp3()
	{
		int num=20;
		if(num>10)
		{
			throw new RuntimeException();
		}
	}
	void disp2()
	{
		disp3();
	}
	void disp1()
	{
		disp2();
	}
	public static void main(String args[])
	{
		HandleException j=new HandleException();
		j.disp1();
	}
}		

					
