package Zip.java;

public class ArithmaticException {
	public static void main(String args[]) {
		try {
			int arr[]=new int[11];
			int ans=arr[10]/0;
			arr[10]=10;
			
		}catch(ArithmeticException | ArrayIndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
