package Zip.java;

public class AssertionExample {
	    public static void main(String[] args) {
	        
	        try {
	        	int age = 15;
	        // Assertion to check if the age is valid
	        assert age >= 18 : "Age is less than 18";
	        }catch(AssertionError  e) {
	        	 System.out.println("Assertion failed: " + e.getMessage());
	        
	        }
	    }
	}

