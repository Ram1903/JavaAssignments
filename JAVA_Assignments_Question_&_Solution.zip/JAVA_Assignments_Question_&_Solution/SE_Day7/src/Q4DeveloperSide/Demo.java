package Q4DeveloperSide;
import java.util.*;
import Q4ClientSide.Authenticator;

public class Demo {
   public static void main(String args[]) {
	  
	   try {

	   Authenticator auth=new Authenticator("Passw");
	   auth.done();
   }catch(InvalidLengthException e){
	   System.out.println(e.getMessage());
	   
   }
   }
}
