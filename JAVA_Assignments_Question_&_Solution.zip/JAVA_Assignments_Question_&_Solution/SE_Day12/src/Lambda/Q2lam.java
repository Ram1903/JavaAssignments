package Lambda;
/*
2) define a functional interface "Second" with an abstract method "void disp4()".

define a class Demo with main function.
inside main function create two implementations of "Second" using lambda expression and display their names.
 */
interface second{
	void disp4();
}
public class Q2lam {
   public static void main(String args[]) {
	   second ref=()->{System.out.println("first ");};
	   second ref1=()->{System.out.println("Second");};
	   
	   ref.disp4();
	   ref1.disp4();
	   System.out.println("Done");
   }
}
