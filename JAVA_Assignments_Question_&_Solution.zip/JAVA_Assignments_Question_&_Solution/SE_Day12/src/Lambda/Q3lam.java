package Lambda;
/*
 
3) define a functional interface "MyInterface" with an abstract method "void fun()"

define a class Demo with two functions "static void perform" and main.

from main function pass lambda expression, collect it in "perform" method and invoke "fun()" function.

 */
interface myInterface{
	void fun();
	
}
public class Q3lam {
   static void perform(myInterface ref) {
	   ref.fun();
	   System.out.println(" in ref");
	  
   }
   public static void main(String args[]) {
	  myInterface lam=()->{System.out.println("Hello");};
	  perform(lam);
	   
   }
}
