package Lambda;
/*
4) define a functional interface "Calculator" with an abstract method "int multiply(int a,int b)"
define a class "CalcDemo" with main method.
inside main using lambda create an implementation of "Calculator" , invoke "multiply()" method and display its result.
 */

interface calculator{
	int multiply(int a,int b);
	
}
public class Q4 {
	public static void main(String args[]) {
		calculator obj=(int a,int b)->{return a*b;};
		int ans=obj.multiply(4, 5);
		System.out.println(ans);
	}
}
