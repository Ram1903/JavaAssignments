package DefaultMethodAsii;
/*
2) define interface "Third" with "default void disp1()" and "static void disp2()" methods.
derive a class "Sub" from "Third" ( do not override "disp1")
inside main function invoke "disp1" and "disp2" methods.
 */
interface third{
	default void disp1() {
		System.out.println("disp1 in third");
	}
	static void disp2() {
		System.out.println("disp2 in third");
	}
}
class sub implements third{
	static void disp2() {
		third.disp2();
		System.out.println("disp2 in sub");
	}
}
public class Q2 {
	public static void main(String args[]) {
		sub obj=new sub();
		obj.disp2();
		obj.disp1();
	}
}
