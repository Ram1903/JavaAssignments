package DefaultMethodAsii;
/*
 
3)define interface "Fourth" with "default void disp3()" method.
define a class "Base1" with "public void disp3()" method,
now derive a class Sub1 from "Base1" and "Fourth". Sub1 class should have only "public void myfun()" method.
inside main create an object of "Sub1" and invoke "disp3".
once you get the result, also try to invoke "disp3" of "Fourth"
 */
interface fourth{
	default void disp3(){
		System.out.println("disp3 in fourth");
		
	}
}
class base1{
	public void disp3() {
		System.out.println("disp3 in base1");
	}
}
class sub1 extends base1 implements fourth{
	public void myfun() {
		fourth.super.disp3();
			
		System.out.println("myfun in sub1");
	}
}
public class Q3 {
	public static void main(String args[]) {
		sub1 obj=new sub1();
		obj.myfun();
		obj.disp3();
		//fourth.disp3();
	}
}
