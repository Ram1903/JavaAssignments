
package DefaultMethodAsii;
/*
 1) define interface "First" with "default void fun()" and interface "Second" with "default void fun()". 
Now derive a class Child from both these interfaces. 
Inside main function instantiate Child class instance and invoke "fun" method.
 */
interface first{
	default void fun() {
		System.out.println("fun in first");
	}
}
interface second{
	default void fun() {
		System.out.println("fun in second");
		
	}
}
class child implements first,second{
	public void fun() {
		first.super.fun();
		second.super.fun();
		System.out.println("fun in child");
	}
}
public class Q1 {
	public static void main(String args[]) {
		child obj=new child();
		obj.fun();
	}
}
