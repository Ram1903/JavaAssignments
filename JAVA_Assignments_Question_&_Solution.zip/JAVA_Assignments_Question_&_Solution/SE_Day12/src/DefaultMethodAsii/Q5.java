package DefaultMethodAsii;
/*
5) define interface "First" with "static void disp1()" method.
class "Base" with "static void disp2()" method.
derive a class "Sub" from "Base" and "First"
now define a class Demo in which define "main" method.
inside main show how many ways you can invoke "disp1" and "disp2"
 */
interface firstf{
	static void disp1() {
		System.out.println("disp1 in firstf");
	}
}
class baseb{
	static void disp2() {
		System.out.println("disp2 in baseb");
	}
}
class subss extends baseb implements firstf{
	void perform(){
		firstf.disp1();
		baseb.disp2();
		System.out.println("perform in sub");
	}
}
public class Q5 {
	public static void main(String args[]) {
		firstf.disp1();
		baseb.disp2();
		subss obj=new subss();
		obj.perform();
	}
}
