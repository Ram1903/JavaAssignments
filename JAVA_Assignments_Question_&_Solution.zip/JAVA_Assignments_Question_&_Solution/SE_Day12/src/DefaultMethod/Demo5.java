package DefaultMethod;
class monitor{
	synchronized synchronized void disp() {
		for(int i=0;i<5;i++) {
			System.out.println("Hello"+Thread.currentThread().getName());
		}
	}
	public synchronized void show() {
		for(int i=0;i<5;i++) {
			System.out.println("Welcome"+Thread.currentThread().getName());
		}
	}
}
public class Demo5 {
 public static void main(String args[]) {
	 monitor obj =new monitor();
		 Thread t1=new Thread(()->{obj.disp();},"firstName");
	 
	 Runnable rn=()->{obj.show();};
		System.out.println("Implementation class of Runnable is\t"+obj.getClass().getName());
	 
		Thread t2=new Thread();
		t1.start();
		t2.start();
 }
}
