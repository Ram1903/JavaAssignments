package DefaultMethod;
interface emp{
	String wish(String name);
	static void show() {
		System.out.println("show in empp1");
	}
	default void disp() {
		System.out.println("disp in emp");
	}
}
public class lambda {
	public static void main(String args[]) {
		emp ref=(String name)->{
			return "Good morning";
		};
		System.out.println(ref.wish("tarun"));
		System.out.println(ref.getClass().getName());
	}
}
