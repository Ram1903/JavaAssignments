package DefaultMethod;
class A{
	void disp1(){
		System.out.println("in disp1");
	}
}
class B extends A{
	void disp2() {
		System.out.println("in disp2");
	}
}
public class one {
	public static void main(String args[]) {
		B b=new B();
		b.disp1();
		b.disp2();
	}
}
