package DefaultMethod;
class Y{
	public String disp2() {
		return "disp in Y";
	}
}
interface Z{
	default String disp2() {
		
		return "disp in Z";
	}
}
class myClass2 extends Y implements Z{
	void perform(){
		System.out.println(Z.super.disp2());
	}
}
public class four {
	public static void main(String args[]) {
		myClass2 m=new myClass2();
		m.disp2();
		m.perform();
	}
}
