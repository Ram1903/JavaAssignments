package DefaultMethod;
/*
4) define a functional interface "Calculator" with an abstract method "int multiply(int a,int b)"
define a class "CalcDemo" with main method.
inside main using lambda create an implementation of "Calculator" , invoke "multiply()" method and display its result.
*/
interface calculator{
	int multiply(int a,int b);
	default void calh() {
		System.out.println("calh");
	}
	static void shh() {
		System.out.println("shh");
	}
}
class mul{
	int multiply(int a,int b) {
		return a*b;
	}
}
public class A33 {
public static void main(String[] args) {
	calculator ref=(int a,int b)->{return a*b;};
	System.out.println(ref.multiply(5, 9));
	ref.calh();
	
}
}
