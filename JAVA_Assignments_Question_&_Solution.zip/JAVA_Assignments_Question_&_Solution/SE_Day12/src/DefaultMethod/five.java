package DefaultMethod;
interface dem{
	static void disp() {
		System.out.println("disp in dem");
	}
	default String show() {
		return "show in dem";
	}
}
public class five implements dem{
	void disp() {
		
		System.out.println("disp in main");
	}
	public String show() {
		dem.super.show();
		return "show in main";
	}
	public static void main(String args[]) {
		five obj=new five();
		obj.disp();
		dem.disp();
		obj.show();
	}
}
