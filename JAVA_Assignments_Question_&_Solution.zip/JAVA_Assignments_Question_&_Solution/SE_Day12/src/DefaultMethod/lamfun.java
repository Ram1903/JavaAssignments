package DefaultMethod;
interface enm{
	String wish(String name); 
}
public class lamfun {
	static void disp(enm ref) {
		System.out.println(ref.wish("Amit"));
		System.out.println(ref.getClass().getName());
	}
	public static void main(String args[]) {
		lamfun.disp((String name)-> {
			return "Hello"+name;
		});
	}
}
