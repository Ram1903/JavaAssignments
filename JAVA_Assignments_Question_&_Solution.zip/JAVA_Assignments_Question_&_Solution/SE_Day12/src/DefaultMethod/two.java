package DefaultMethod;
interface A1{
	String disp();
	default String show() {
		return "disp in A";
	}
}
interface B1{
	String disp();
	default String show() {
		return "disp in B";
	}
}
class myClass implements A1,B1{
	public String disp() {
		System.out.println("disp in myClass");
		return null;
	}

	@Override
	public String show() {
		// TODO Auto-generated method stub
		return B1.super.show();
	}

	
}
public class two {
	public static void main(String args[]) {
		myClass m=new myClass();
		System.out.println(m.disp());
		System.out.println(m.show());
	}
}
