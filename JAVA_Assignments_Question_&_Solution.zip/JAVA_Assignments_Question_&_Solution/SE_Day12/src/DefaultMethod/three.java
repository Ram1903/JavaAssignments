package DefaultMethod;
interface A2{
	String disp();
	default String show() {
		return "in A show";
	}
}
interface B2 extends A2{
	String disp();
	default String show() {
		return "in B show";
	}
}
class c implements B2{

	public String disp() {
		return "in c disp";
	}
	
	
}
class three {
	public static void main(String args[]) {
		c obj=new c();
		System.out.println(obj.disp());
		System.out.println(obj.show());
	}
}
