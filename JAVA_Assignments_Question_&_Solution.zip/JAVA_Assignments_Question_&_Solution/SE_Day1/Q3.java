package SE_Day1;
/*
 5)	Using if…….else if….  Else,  display whether result is  fail, pass, second class , first class, Distinction etc.  

 */
import java.util.Scanner;
public class Q3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        if(n>=75){
            System.out.println("Grade A");
        }else if(n>=55){
            System.out.println("Grade B");
        }else if(n>=35){
            System.out.println("Grade A");
        }else {
            System.out.println("Fail");
        }
    }
}
