package SE_Day1;
//2)	declare two numbers and one operator as a character. e.g. '+'
//using switch... case check which operator is declared and accordingly perform the action.
import java.util.Scanner;
public class Q2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a = sc.nextInt();
        int b=sc.nextInt();
        System.out.println("Enter choice:\n1.+\n2.-\n3.*\n4./");
        int ch=sc.nextInt();
        switch(ch){
            case 1:System.out.println(a+b);break;
            case 2:System.out.println(a-b);break;
            case 3:System.out.println(a*b);break;
            case 4:System.out.println(a/b);break;
        }
    }
}
