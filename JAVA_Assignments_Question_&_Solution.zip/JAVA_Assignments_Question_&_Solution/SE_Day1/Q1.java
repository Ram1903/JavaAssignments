package SE_Day1;
import java.util.Scanner;
public class Q1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        for(int i=1;i<=10;i++)
            System.out.println(n*i);


        for(int j=1;j<=10;j++){
            System.out.println(j);
        }

        for(int i=3;i<=30;i++){
            if(i!=24){
                System.out.print(i+" ");
            }
        }
    }
    

/*
 1)	display a table of a particular number           

3)	Display numbers  1 to 10 using loop
4)	Display numbers from 3 to 30 except number 24  using loop.

6) display all prime numbers between 3 to 30

7) using nested for loop display following :

A  a
A  b
A  c

B  a
B  b
B  c

C  a
C  b
C  c

8) solve following patten programs:


    * 
   * * 
  * * * 
 * * * * 
* * * * * 



       * * * * 
  	* * * 
  	 * * 
          * 


    * 
   * * 
  * * * 
 * * * * 
  * * * 
   * * 
    * 


11) display all prime numbers between 3 to 30

13) using nested for loop display following :

A  a
A  b
A  c

B  a
B  b
B  c

C  a
C  b
C  c




 */
}
