package SE_Day2;
/*
 
4) Define a class "DemoOb". 
create an instance of it.
now create a reference and assign the reference created in the above statement.
	Discuss what happens?
Now since u have 2 references, take one of the reference and assign a new instance of the class.
	Discuss what happens?
(For ur discussion, write necessary comments in the program)
 */
class DemoOb{

    private int num;
    public int setNum(int n){
        this.num=n;
        return num;
    }
    public void getNum(){
        System.out.println(num);
    }
}
public class Q4 {
    public static void main(String[] args) {
        System.out.println(" ");
        DemoOb ob1=new DemoOb();
        DemoOb ob2=new DemoOb();
        ob2.getNum();
        ob1.setNum(100);
        ob1.getNum();
        ob2.getNum();
    }
}
