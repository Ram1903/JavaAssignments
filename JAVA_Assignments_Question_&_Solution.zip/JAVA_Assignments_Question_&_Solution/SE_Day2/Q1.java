package SE_Day2;
//1)create a class "Shape" with 2 attributes, "width" and "height". Make sure one can not access these attributes directly.
//provide accessor methods on these attributes and allow them to call from outside of your class.
class shape{

    private int width;
    private int height;

    public void setWidth(int x){
        this.width=x;

    }

   public void  setHeight(int y){
        this.height=y;
    }
   public int showData(){
    //return this.width+this.height;
    return height;
    
   }
   public int showData2(){
    return width;
   }
    
    }
public class Q1 {
    public static void main(String[] args) {
        System.out.println(" ");
        shape sq=new shape();
        sq.setWidth(2);
        sq.setHeight(4);
        int ans=sq.showData();
        int ans2=sq.showData2();
        
        System.out.println(ans+" "+ans2);
    }
}
