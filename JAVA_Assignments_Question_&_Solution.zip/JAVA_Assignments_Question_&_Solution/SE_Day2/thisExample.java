package SE_Day2;
class sq{
    private int sq;
    public int sq(int sq){
        this.sq=sq;
        return sq;
    }
    public void getsq(){
        System.out.println(sq);
    }
}
public class thisExample {
    public static void main(String args[]){
        System.out.println(" ");
        sq s=new sq();
        s.sq(3);
        s.getsq();
    }
    
}
