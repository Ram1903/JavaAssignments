package SE_Day2;
// //
// 2) Define a class "MyClass" and make sure clients can instantiate it , 
// a) without any argument
// b) with one int argument
// c) with two int arguments


class Myclass{

    private int a,b,c;
    public void Myclass(){
        System.out.println(" withaut any argument");
    }
    public int Myclass(int x){
        a=x;
        return a;
    }
    public int Myclass(int x,int y){
        a=x;
        b=y;
        return a+b;
    }
}
public class Q2 {
    public static void main(String[] args) {
        System.out.println(" ");
        Myclass a=new Myclass();

        a.Myclass();
        int ans1=a.Myclass(4);
        ans1=a.Myclass(9);
        int ans2=a.Myclass(1,5);
        System.out.println(ans1+" "+ans2);
    }
    
}
