package SE_Day2;
/*
 
5) Define 3 classes A , B and C
in all these classes create static and nonstatic variables as well as methods.
	Now Define a class "Demo" ,in which define "main" function. From this main function try to access all the members of A ,B  and C.
 */

 class A{//employee id
    private int id;
    public static int c=0;
   public int cnt=c;

    public int setId(int n){
        id=n;
        c++;
        cnt=c;
        return id;
    }

    public int getId(){
        return id;
    }
 }
 class B{//employee name
    private static String nam;
    public void setName(String n){
        nam=n;
    }
    public void getNam(){
        System.out.println(nam);
    }

 }
 class C{//employee department
    private static String dept;
    public String dep(String d){
        dept=d;
        return dept;
    }
    public void getDept(){
        String de=dept;
        System.out.println(de);
    }

 }
public class Q5 {
    public static void main(String args[]){
        System.out.println(" ");
        A a=new A();
        a.setId(24);
        System.out.println(a.getId());
        B n=new B();
        n.setName("Tarun");
        n.getNam();
        C de=new C();
        de.dep("Tech");
        de.getDept();
    }
}
