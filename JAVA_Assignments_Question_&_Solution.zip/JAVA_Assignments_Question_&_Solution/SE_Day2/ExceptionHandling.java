package SE_Day2;

public class ExceptionHandling {
    public static void main(String args[]){
        System.out.println(" ");
        
        try{
            int a=3/0;
            System.out.println(a);
        }catch(ArithmeticException e){
            System.out.println("Exception");
        }
    }
    
}
