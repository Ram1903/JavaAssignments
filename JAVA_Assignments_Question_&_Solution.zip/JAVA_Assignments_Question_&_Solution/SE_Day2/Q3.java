package SE_Day2;
/*
 
3) Define a class "Emp" with private static member "int cnt".
How will u make sure that outsiders can read the value of cnt ?

 */


 import java.util.*;
 class Emp{

    private static String n;
    private static  int cnt;
    private static int c=0;

    public static void setName(String name){
        c++;
        n=name;
        cnt=c;
        
    }

    public static int showData(){
        return cnt;
    }
 }
public class Q3 {
    public static void main(String[] args) {
        System.out.println(" ");
        Emp e1=new Emp();
        Emp.setName("Tarun");
        System.out.println(Emp.showData());
    }
    
}
